class aravish:
    import numpy as np
    from scrapeasy import Website, Page
    import time