# Inside of __init__.py
from pypihero.Class1 import aravish